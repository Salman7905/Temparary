using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using UserMgmt.API.DTOs;
using DataAccessLayer;
using BusinessLogicLayer;
using Domain;

namespace UserMgmt.API.Controllers
{
    [ApiController]
    [Route("Taazaa/[controller]")]
    public class OnionController: ControllerBase
    {
        private readonly IUserService userService;
        private readonly IUserProfileService userProfileService;
        public OnionController(IUserService _userService, IUserProfileService _userProfileService)
        {
           userService = _userService; 
           userProfileService = _userProfileService;
        }

        //Add Data

        [HttpPost]
        [Route("Add User")]
        public ActionResult AddUser(UserDTO model)
        {
            User userEntity = new User
            {
                UserName = model.UserName,
                Email = model.Email,
                Password = model.Password,
                AddedDate = DateTime.UtcNow,
                ModifiedDate = DateTime.UtcNow,
                IPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString(),
                UserProfile = new UserProfile
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Address = model.Address,
                    AddedDate = DateTime.UtcNow,
                    ModifiedDate = DateTime.UtcNow,
                    IPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString()
                }
            };
            userService.InsertUser(userEntity);
            if (userEntity.Id > 0)
            {
                return RedirectToAction("index");
            }
            return Ok(model);
        }

        //Get data
        [HttpGet]
        [Route("Get User")]
        public IActionResult Index()
        {
            List<UserDTO> model = new List<UserDTO>();
            userService.GetUsers().ToList().ForEach(u =>
            {
                UserProfile userProfile = userProfileService.GetUserProfile(u.Id);
                UserDTO user = new UserDTO
                {
                    Id = u.Id,
                    Name = $"{userProfile.FirstName} {userProfile.LastName}",
                    Email = u.Email,
                    Address = userProfile.Address
                };
                model.Add(user);
            });
 
            return Ok(model);
        }

        //Edit
        [HttpPost]
        [Route("Update User")]
        public IActionResult EditUser(UserDTO model)
        {
            User userEntity = userService.GetUser(model.Id);
            userEntity.Email = model.Email;
            userEntity.ModifiedDate = DateTime.UtcNow;
            userEntity.IPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            UserProfile userProfileEntity = userProfileService.GetUserProfile(model.Id);
            userProfileEntity.FirstName = model.FirstName;
            userProfileEntity.LastName = model.LastName;
            userProfileEntity.Address = model.Address;
            userProfileEntity.ModifiedDate = DateTime.UtcNow;
            userProfileEntity.IPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            userEntity.UserProfile = userProfileEntity;
            userService.UpdateUser(userEntity);
            if (userEntity.Id > 0)
            {
                return RedirectToAction("index");
            }
            return Ok(model);
        }

        //Delete
        [HttpDelete]
        [Route("Delete User")]
        public ActionResult DeleteUser(Int64 id)
        {
            userService.DeleteUser(id);         
            return Ok("Deleted");
        }
    }
}